export default function NotFound(){
    return(
        <h1>Do not proceed Dark Web Ahead</h1>
    )
} 