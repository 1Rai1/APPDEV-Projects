export default function About(){
    return(
        <>
            <h1>This is my About Page</h1>
            <p>This will showcase the basics of React Routing</p>    
        </>
    )
}