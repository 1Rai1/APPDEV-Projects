import React from 'react'
import './CSS/NavBar.css'
export default function NavBar(){
    return(
        <>
        <nav className='Nav'>
        <div class="navbar-content"></div>
        <div className='center'> Johto Region</div>
        </nav>
        </>
    )
}