export default function Footer(){
    return(
        <footer>
            <hr />
            <p>&copy; {new Date().getFullYear()} Johto Pokedex
            Website || Written by: Clayton Soronio & Rainier Doquilo </p>
        </footer>
    )
}