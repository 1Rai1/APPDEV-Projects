//this is my footer component
export default function Footer(){
    return(
        <footer>
            <p>
                &copy; {new Date().getFullYear()} My Food Website || Written by: Tom Hanks
            </p>
        </footer>
    )
}