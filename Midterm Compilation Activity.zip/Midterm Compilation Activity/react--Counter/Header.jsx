export default function Header(){
    //stateless component - no hooks, no functions, no states return texts
  return (
      <header>
          <h1><center>My Counter Project</center></h1>
          <hr />  
      </header>
     
      
  )
}
