export default function Header(){
    //stateless component - no hooks, no functions, no states return texts
  return (
      <header>
          <h1><center>My List of Favorite Games</center></h1>
          <hr />  
      </header>
     
      
  )
}
