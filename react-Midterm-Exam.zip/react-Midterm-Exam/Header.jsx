export default function Header(){
    return(
        <>
        <header><h1><center>My Midterm Web Examination Page </center></h1></header>
        </>
    )
}