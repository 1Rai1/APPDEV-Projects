export default function Footer(){
    return(
        <>
        <footer><h5><center>Clayton Soronio {new Date().getFullYear()} </center></h5></footer>
        </>
    )
}