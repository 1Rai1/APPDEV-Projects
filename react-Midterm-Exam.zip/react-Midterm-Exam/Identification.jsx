export default function Identification(){
    return(
        <>
        <p>Name: Clayton Soronio</p><br/>
        <p>Age: 19</p><br/>
        <p>Course: Computer Science</p><br/>
        <p>Dream Job: Secret</p><br/>
       
        </>
    )
}