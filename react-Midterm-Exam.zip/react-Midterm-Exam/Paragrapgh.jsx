export default function Paragraph(){
    return(
        <p>Hello, I am Mr. Murphy! Nice to finally meet you.</p>
    )
}